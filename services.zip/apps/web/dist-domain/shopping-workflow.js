/**
 * Runtime extensions to the shopping journey (WEB-SHP-001): batch accept/reject, completion to
 * inventory, list sharing attribution, archive with retained history, and in-app shopping
 * notifications. Every mutation keeps the same explicit conflict/offline/retryable recovery
 * vocabulary as the rest of the web runtime.
 */
export function beginShoppingBatchAction(action, itemIds, listVersion) {
    const uniqueIds = dedupeIds(itemIds);
    if (uniqueIds.length === 0) {
        return {
            state: "RETRYABLE_ERROR",
            action,
            itemIds: uniqueIds,
            failedItemIds: [],
            listVersion,
            message: "Select at least one item.",
        };
    }
    if (!Number.isInteger(listVersion) || listVersion < 0) {
        return {
            state: "RETRYABLE_ERROR",
            action,
            itemIds: uniqueIds,
            failedItemIds: uniqueIds,
            listVersion,
            message: "The shopping list version is invalid.",
        };
    }
    return {
        state: "SUBMITTING",
        action,
        itemIds: uniqueIds,
        failedItemIds: [],
        listVersion,
        message: `Saving ${uniqueIds.length} item${uniqueIds.length === 1 ? "" : "s"}.`,
    };
}
export function resolveShoppingBatchResult(model, result) {
    if (result.outcome === "SUCCESS") {
        return { ...model, state: "SUCCESS", failedItemIds: [], message: batchSuccessMessage(model) };
    }
    if (result.outcome === "PARTIAL_SUCCESS") {
        const failedItemIds = result.failedItemIds.filter((id) => model.itemIds.includes(id));
        return {
            ...model,
            state: "PARTIAL_SUCCESS",
            failedItemIds,
            message: `${model.itemIds.length - failedItemIds.length} of ${model.itemIds.length} items saved. Review the rest.`,
        };
    }
    const messages = {
        CONFLICT: "The list changed elsewhere. Review before retrying.",
        RETRYABLE_ERROR: "The batch action can be retried.",
        OFFLINE: "You are offline. The batch action will retry when connected.",
    };
    return {
        ...model,
        state: result.outcome,
        failedItemIds: model.itemIds,
        message: messages[result.outcome],
    };
}
function batchSuccessMessage(model) {
    const verb = model.action === "ACCEPT" ? "accepted" : "rejected";
    return `${model.itemIds.length} item${model.itemIds.length === 1 ? "" : "s"} ${verb}.`;
}
function dedupeIds(itemIds) {
    const trimmed = itemIds.map((id) => id.trim()).filter((id) => id.length > 0);
    return [...new Set(trimmed)];
}
export function beginCompletionToStock(input) {
    if (input.listId.trim() === "") {
        return {
            state: "RETRYABLE_ERROR",
            listId: input.listId,
            candidates: [],
            failedItemIds: [],
            message: "The shopping list is unavailable.",
        };
    }
    const candidates = input.completedItems
        .filter((item) => item.itemId.trim() !== "" && item.quantity > 0)
        .map((item) => ({ ...item, confirmedQuantity: item.quantity }));
    return {
        state: "READY",
        listId: input.listId,
        candidates,
        failedItemIds: [],
        message: candidates.length === 0
            ? "No completed items to load into inventory."
            : "Confirm quantities before loading purchased items into inventory.",
    };
}
export function confirmCompletionQuantity(model, itemId, confirmedQuantity) {
    if (!Number.isFinite(confirmedQuantity) || confirmedQuantity <= 0)
        return model;
    return {
        ...model,
        candidates: model.candidates.map((candidate) => candidate.itemId === itemId ? { ...candidate, confirmedQuantity } : candidate),
    };
}
export function submitCompletionToStock(model) {
    if (model.candidates.length === 0) {
        return {
            ...model,
            state: "RETRYABLE_ERROR",
            message: "There are no confirmed items to load into inventory.",
        };
    }
    return {
        ...model,
        state: "SUBMITTING",
        message: `Loading ${model.candidates.length} item${model.candidates.length === 1 ? "" : "s"} into inventory.`,
    };
}
export function resolveCompletionToStock(model, result) {
    if (result.outcome === "SUCCESS") {
        return {
            ...model,
            state: "SUCCESS",
            failedItemIds: [],
            message: "Purchased items were loaded into inventory.",
        };
    }
    if (result.outcome === "PARTIAL_SUCCESS") {
        const failedItemIds = result.failedItemIds.filter((id) => model.candidates.some((candidate) => candidate.itemId === id));
        return {
            ...model,
            state: "PARTIAL_SUCCESS",
            failedItemIds,
            message: `${model.candidates.length - failedItemIds.length} of ${model.candidates.length} items loaded. Review the rest.`,
        };
    }
    const messages = {
        CONFLICT: "Inventory changed elsewhere. Review before retrying.",
        RETRYABLE_ERROR: "Loading purchased items can be retried.",
        OFFLINE: "You are offline. Loading purchased items will retry when connected.",
    };
    return {
        ...model,
        state: result.outcome,
        failedItemIds: model.candidates.map((candidate) => candidate.itemId),
        message: messages[result.outcome],
    };
}
export function describeListActivity(activity, viewerUserId) {
    if (activity.lastEditedByUserId === undefined) {
        return activity.sharedWithCount > 0
            ? `Shared with ${activity.sharedWithCount} family member${activity.sharedWithCount === 1 ? "" : "s"}. No changes yet.`
            : "No recent changes.";
    }
    if (activity.lastEditedByUserId === viewerUserId)
        return "You made the last change.";
    const editor = activity.lastEditedByDisplayName ?? "A family member";
    return `${editor} made the last change.`;
}
export function beginArchiveList(listId, listVersion) {
    if (listId.trim() === "" || !Number.isInteger(listVersion) || listVersion < 0) {
        return {
            state: "RETRYABLE_ERROR",
            listId,
            listVersion,
            message: "The shopping list is unavailable.",
        };
    }
    return {
        state: "ARCHIVING",
        listId,
        listVersion,
        message: "Archiving the shopping list. History will remain available.",
    };
}
export function resolveArchiveResult(model, result) {
    const messages = {
        SUCCESS: "Shopping list archived. History remains available.",
        CONFLICT: "The list changed elsewhere. Review before archiving.",
        RETRYABLE_ERROR: "Archiving can be retried.",
        OFFLINE: "You are offline. Archiving will retry when connected.",
    };
    return {
        ...model,
        state: result === "SUCCESS" ? "ARCHIVED" : result,
        message: messages[result],
    };
}
export function unreadShoppingNotificationCount(notifications) {
    return notifications.filter((notification) => notification.readAt === undefined).length;
}
export function markShoppingNotificationRead(notifications, notificationId, now) {
    return notifications.map((notification) => notification.id === notificationId ? { ...notification, readAt: now } : notification);
}
//# sourceMappingURL=shopping-workflow.js.map