const NAVIGATION = [
    { href: "/inventory", label: "Inventory" },
    { href: "/shopping", label: "Shopping list" },
    { href: "/family", label: "Family" },
];
export function createShellModel(input) {
    const currentPath = input.currentPath ?? "/";
    return {
        principal: input.principal,
        family: input.family,
        state: input.state ?? "LOADING",
        errorMessage: input.errorMessage,
        navigation: NAVIGATION.map((item) => ({
            ...item,
            current: currentPath === item.href || currentPath.startsWith(`${item.href}/`),
        })),
    };
}
export function resolveSafeRedirect(value, fallback = "/inventory") {
    if (value === undefined || !value.startsWith("/") || value.startsWith("//"))
        return fallback;
    return value;
}
export function shellStatusMessage(model) {
    if (model.state === "LOADING")
        return "Loading family workspace";
    if (model.state === "OFFLINE")
        return "You are offline. Changes will retry when connected.";
    if (model.state === "RETRYING")
        return "Retrying connection";
    if (model.state === "ERROR")
        return model.errorMessage ?? "Unable to load the family workspace";
    return model.family === undefined
        ? "Select a family to continue"
        : `Working in ${model.family.displayName}`;
}
//# sourceMappingURL=shell.js.map