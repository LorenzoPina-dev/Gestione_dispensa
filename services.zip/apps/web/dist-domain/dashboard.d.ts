export type DashboardState = "LOADING" | "READY" | "EMPTY" | "OFFLINE" | "ERROR";
export type DashboardAlertKind = "EXPIRED" | "EXPIRING" | "LOW_STOCK";
export interface DashboardAlert {
    readonly kind: DashboardAlertKind;
    readonly count: number;
}
export interface DashboardSummary {
    readonly lowStockCount: number;
    readonly expiringCount: number;
    readonly expiredCount: number;
    readonly activeShoppingListId?: string;
    readonly activeShoppingListPendingCount: number;
    readonly unreadNotificationCount: number;
}
export type DashboardQuickActionId = "REVIEW_EXPIRED" | "REVIEW_EXPIRING" | "REVIEW_LOW_STOCK" | "REVIEW_SHOPPING_LIST" | "REVIEW_NOTIFICATIONS" | "ADD_PRODUCT";
export interface DashboardQuickAction {
    readonly id: DashboardQuickActionId;
    readonly href: string;
    readonly label: string;
}
export interface DashboardModel {
    readonly state: DashboardState;
    readonly alerts: readonly DashboardAlert[];
    readonly quickActions: readonly DashboardQuickAction[];
    readonly message: string;
}
/**
 * Builds the dashboard overview. The dashboard prioritizes actionable items over raw metrics:
 * quick actions are ordered by urgency (expired, then expiring, then the active shopping list,
 * then low stock, then notifications) and always fall back to "add a product" so the panel is
 * never empty for an active family with no alerts.
 */
export declare function buildDashboard(input: {
    readonly online: boolean;
    readonly errorMessage?: string;
    readonly summary?: DashboardSummary;
}): DashboardModel;
