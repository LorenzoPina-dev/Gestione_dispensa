import { type ShellModel } from "./shell.js";
export interface OidcCallbackInput {
    readonly code?: string;
    readonly state?: string;
    readonly expectedState: string;
    readonly redirectTo?: string;
}
export interface BrowserRuntime {
    readonly shell: ShellModel;
    readonly redirectTo: string;
    readonly oidcCode?: string;
}
export declare function createBrowserRuntime(input: {
    readonly path?: string;
    readonly principal?: {
        readonly userId: string;
        readonly displayName: string;
    };
    readonly family?: {
        readonly familyId: string;
        readonly displayName: string;
    };
    readonly online?: boolean;
    readonly errorMessage?: string;
}): BrowserRuntime;
export declare function consumeOidcCallback(input: OidcCallbackInput): BrowserRuntime;
export declare function renderPwaDocument(model: ShellModel): string;
