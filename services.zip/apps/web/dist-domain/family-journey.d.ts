export type FamilyJourneyState = "NO_FAMILY" | "CREATING" | "ACTIVE" | "PENDING_AUTHENTICATION" | "PENDING_REVIEW" | "ACCEPTED" | "REJECTED" | "EXPIRED" | "UNAVAILABLE";
export interface FamilyJourneyModel {
    readonly state: FamilyJourneyState;
    readonly returnTo: string;
    readonly familyName?: string;
    readonly proposedRole?: "MANAGER" | "MEMBER" | "VIEWER";
    readonly expiresAt?: string;
    readonly message: string;
}
export declare function resolveJoinEntry(queryValue: string | undefined): FamilyJourneyModel;
export declare function reviewInvite(input: {
    readonly familyName: string;
    readonly proposedRole: "MANAGER" | "MEMBER" | "VIEWER";
    readonly expiresAt: string;
    readonly returnTo?: string;
}): FamilyJourneyModel;
export declare function acceptInvite(familyId: string): FamilyJourneyModel;
