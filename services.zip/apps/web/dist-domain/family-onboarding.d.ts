export type FamilyOnboardingState = "NO_FAMILY" | "CREATING" | "CREATE_ERROR" | "PENDING_AUTHENTICATION" | "PENDING_REVIEW" | "ACCEPTING" | "ACCEPTED" | "REJECTED" | "SWITCHING" | "ACTIVE" | "ERROR";
export interface FamilyOnboardingModel {
    readonly state: FamilyOnboardingState;
    readonly route: string;
    readonly activeFamilyId?: string;
    readonly familyName?: string;
    readonly message: string;
}
export declare function startOnboarding(): FamilyOnboardingModel;
export declare function startFamilyCreation(input: {
    readonly displayName: string;
    readonly returnTo?: string;
}): FamilyOnboardingModel;
export declare function completeFamilyCreation(input: {
    readonly familyId: string;
    readonly displayName: string;
}): FamilyOnboardingModel;
export declare function beginInviteEntry(token: string | undefined): FamilyOnboardingModel;
export declare function reviewInviteRoute(input: {
    readonly attemptId: string;
    readonly familyName: string;
}): FamilyOnboardingModel;
export declare function acceptInviteRoute(attemptId: string): FamilyOnboardingModel;
export declare function completeInviteAcceptance(input: {
    readonly familyId: string;
    readonly familyName: string;
}): FamilyOnboardingModel;
export declare function rejectInvite(attemptId: string): FamilyOnboardingModel;
export declare function switchFamily(input: {
    readonly currentFamilyId?: string;
    readonly targetFamilyId: string;
}): FamilyOnboardingModel;
export declare function completeFamilySwitch(input: {
    readonly familyId: string;
    readonly familyName: string;
}): FamilyOnboardingModel;
