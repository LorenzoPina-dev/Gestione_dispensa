export function beginProductInput(source) {
    return {
        source,
        state: "INPUT",
        message: source === "MANUAL" ? "Enter product details." : "Add a product image or identifier.",
        retryable: false,
    };
}
export function resolveProductInput(model, result) {
    const messages = {
        CANDIDATE: "Review the product before adding it.",
        MANUAL_REQUIRED: "Review and enter the product manually.",
        SUCCESS: "Product added to inventory.",
        OFFLINE: "You are offline. Retry when connected.",
        CONFLICT: "Inventory changed elsewhere. Review before retrying.",
        RETRYABLE_ERROR: "The product action can be retried.",
    };
    return {
        ...model,
        state: result === "CANDIDATE" ? "REVIEW" : result,
        message: messages[result],
        retryable: result === "OFFLINE" || result === "CONFLICT" || result === "RETRYABLE_ERROR",
    };
}
export function getExpiryState(expiresAt, now, expiringWithinDays = 7) {
    if (expiresAt === undefined)
        return "UNKNOWN";
    const expiry = Date.parse(expiresAt);
    const current = Date.parse(now);
    if (!Number.isFinite(expiry) || !Number.isFinite(current) || expiringWithinDays < 0) {
        return "UNKNOWN";
    }
    const daysUntilExpiry = (expiry - current) / 86_400_000;
    if (daysUntilExpiry < 0)
        return "EXPIRED";
    return daysUntilExpiry <= expiringWithinDays ? "EXPIRING" : "FRESH";
}
//# sourceMappingURL=inventory-workflow.js.map