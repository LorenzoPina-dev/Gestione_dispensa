import { resolveSafeRedirect } from "./shell.js";
export function startOnboarding() {
    return model("NO_FAMILY", "/onboarding", "Create a family or join with an invite.");
}
export function startFamilyCreation(input) {
    if (input.displayName.trim() === "") {
        return model("CREATE_ERROR", "/onboarding", "Enter a family name.");
    }
    return {
        state: "CREATING",
        route: resolveSafeRedirect(input.returnTo, "/onboarding"),
        familyName: input.displayName.trim(),
        message: "Creating your family workspace.",
    };
}
export function completeFamilyCreation(input) {
    return activateFamily(input.familyId, input.displayName);
}
export function beginInviteEntry(token) {
    if (token === undefined || token.trim() === "") {
        return model("ERROR", "/join", "Invitation is unavailable.");
    }
    return model("PENDING_AUTHENTICATION", "/join", "Sign in to review this invitation.");
}
export function reviewInviteRoute(input) {
    if (input.attemptId.trim() === "" || input.familyName.trim() === "") {
        return model("ERROR", "/join", "Invitation is unavailable.");
    }
    return {
        state: "PENDING_REVIEW",
        route: `/join/${encodeURIComponent(input.attemptId)}/review`,
        familyName: input.familyName.trim(),
        message: "Review the invitation before accepting.",
    };
}
export function acceptInviteRoute(attemptId) {
    if (attemptId.trim() === "")
        return model("ERROR", "/join", "Invitation is unavailable.");
    return {
        state: "ACCEPTING",
        route: `/join/${encodeURIComponent(attemptId)}/accept`,
        message: "Joining the family workspace.",
    };
}
export function completeInviteAcceptance(input) {
    return activateFamily(input.familyId, input.familyName);
}
export function rejectInvite(attemptId) {
    if (attemptId.trim() === "")
        return model("ERROR", "/join", "Invitation is unavailable.");
    return model("REJECTED", "/inventory", "Invitation declined.");
}
export function switchFamily(input) {
    if (input.targetFamilyId.trim() === "" || input.targetFamilyId === input.currentFamilyId) {
        return model("ERROR", "/family", "Choose a different family.");
    }
    return {
        state: "SWITCHING",
        route: `/families/${encodeURIComponent(input.targetFamilyId)}/welcome`,
        activeFamilyId: input.targetFamilyId,
        message: "Switching family workspace.",
    };
}
export function completeFamilySwitch(input) {
    const active = activateFamily(input.familyId, input.familyName);
    return { ...active, state: "ACTIVE", message: `Working in ${input.familyName}.` };
}
function activateFamily(familyId, familyName) {
    if (familyId.trim() === "" || familyName.trim() === "") {
        return model("ERROR", "/family", "Family workspace is unavailable.");
    }
    return {
        state: "ACCEPTED",
        route: `/families/${encodeURIComponent(familyId)}/welcome`,
        activeFamilyId: familyId,
        familyName: familyName.trim(),
        message: "Welcome to your family workspace.",
    };
}
function model(state, route, message) {
    return { state, route, message };
}
//# sourceMappingURL=family-onboarding.js.map