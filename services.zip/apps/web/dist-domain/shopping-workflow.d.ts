/**
 * Runtime extensions to the shopping journey (WEB-SHP-001): batch accept/reject, completion to
 * inventory, list sharing attribution, archive with retained history, and in-app shopping
 * notifications. Every mutation keeps the same explicit conflict/offline/retryable recovery
 * vocabulary as the rest of the web runtime.
 */
export type ShoppingBatchAction = "ACCEPT" | "REJECT";
export type ShoppingBatchState = "SUBMITTING" | "SUCCESS" | "PARTIAL_SUCCESS" | "CONFLICT" | "RETRYABLE_ERROR" | "OFFLINE";
export interface ShoppingBatchModel {
    readonly state: ShoppingBatchState;
    readonly action: ShoppingBatchAction;
    readonly itemIds: readonly string[];
    readonly failedItemIds: readonly string[];
    readonly listVersion: number;
    readonly message: string;
}
export declare function beginShoppingBatchAction(action: ShoppingBatchAction, itemIds: readonly string[], listVersion: number): ShoppingBatchModel;
export type ShoppingBatchOutcome = {
    readonly outcome: "SUCCESS";
} | {
    readonly outcome: "PARTIAL_SUCCESS";
    readonly failedItemIds: readonly string[];
} | {
    readonly outcome: "CONFLICT";
} | {
    readonly outcome: "RETRYABLE_ERROR";
} | {
    readonly outcome: "OFFLINE";
};
export declare function resolveShoppingBatchResult(model: ShoppingBatchModel, result: ShoppingBatchOutcome): ShoppingBatchModel;
export type CompletionToStockState = "READY" | "SUBMITTING" | "SUCCESS" | "PARTIAL_SUCCESS" | "CONFLICT" | "RETRYABLE_ERROR" | "OFFLINE";
export interface CompletedShoppingItem {
    readonly itemId: string;
    readonly productId?: string;
    readonly displayName: string;
    readonly quantity: number;
}
export interface CompletionToStockCandidate extends CompletedShoppingItem {
    readonly confirmedQuantity: number;
}
export interface CompletionToStockModel {
    readonly state: CompletionToStockState;
    readonly listId: string;
    readonly candidates: readonly CompletionToStockCandidate[];
    readonly failedItemIds: readonly string[];
    readonly message: string;
}
export declare function beginCompletionToStock(input: {
    readonly listId: string;
    readonly completedItems: readonly CompletedShoppingItem[];
}): CompletionToStockModel;
export declare function confirmCompletionQuantity(model: CompletionToStockModel, itemId: string, confirmedQuantity: number): CompletionToStockModel;
export declare function submitCompletionToStock(model: CompletionToStockModel): CompletionToStockModel;
export declare function resolveCompletionToStock(model: CompletionToStockModel, result: ShoppingBatchOutcome): CompletionToStockModel;
export interface ShoppingListActivity {
    readonly listId: string;
    readonly lastEditedByUserId?: string;
    readonly lastEditedByDisplayName?: string;
    readonly lastEditedAt?: string;
    readonly sharedWithCount: number;
}
export declare function describeListActivity(activity: ShoppingListActivity, viewerUserId: string): string;
export type ShoppingArchiveState = "ARCHIVING" | "ARCHIVED" | "CONFLICT" | "RETRYABLE_ERROR" | "OFFLINE";
export interface ShoppingArchiveModel {
    readonly state: ShoppingArchiveState;
    readonly listId: string;
    readonly listVersion: number;
    readonly message: string;
}
export declare function beginArchiveList(listId: string, listVersion: number): ShoppingArchiveModel;
export declare function resolveArchiveResult(model: ShoppingArchiveModel, result: "SUCCESS" | "CONFLICT" | "RETRYABLE_ERROR" | "OFFLINE"): ShoppingArchiveModel;
export type ShoppingNotificationCategory = "LIST_SHARED" | "ITEM_ADDED" | "LIST_ARCHIVED" | "REORDER_SUGGESTED";
export interface ShoppingNotification {
    readonly id: string;
    readonly category: ShoppingNotificationCategory;
    readonly title: string;
    readonly body: string;
    readonly readAt?: string;
}
export declare function unreadShoppingNotificationCount(notifications: readonly ShoppingNotification[]): number;
export declare function markShoppingNotificationRead(notifications: readonly ShoppingNotification[], notificationId: string, now: string): readonly ShoppingNotification[];
