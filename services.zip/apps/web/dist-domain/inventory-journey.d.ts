export type InventoryAction = "RECEIPT" | "CONSUMPTION" | "WASTE" | "ADJUSTMENT";
export type InventoryActionState = "IDLE" | "SUBMITTING" | "SUCCESS" | "CONFLICT" | "RETRYABLE_ERROR" | "OFFLINE";
export interface InventoryJourneyModel {
    readonly state: InventoryActionState;
    readonly action: InventoryAction;
    readonly message: string;
    readonly version?: number;
}
export declare function beginInventoryAction(action: InventoryAction, version: number): InventoryJourneyModel;
export declare function resolveInventoryResult(model: InventoryJourneyModel, result: "SUCCESS" | "CONFLICT" | "RETRYABLE_ERROR" | "OFFLINE"): InventoryJourneyModel;
