import { resolveSafeRedirect } from "./shell.js";
export function resolveJoinEntry(queryValue) {
    if (queryValue === undefined || queryValue.trim() === "") {
        return model("UNAVAILABLE", "Invitation is unavailable.");
    }
    return model("PENDING_AUTHENTICATION", "Sign in to review this invitation.");
}
export function reviewInvite(input) {
    return {
        state: "PENDING_REVIEW",
        returnTo: resolveSafeRedirect(input.returnTo, "/join/review"),
        familyName: input.familyName,
        proposedRole: input.proposedRole,
        expiresAt: input.expiresAt,
        message: "Review the invitation before accepting.",
    };
}
export function acceptInvite(familyId) {
    if (familyId.trim() === "")
        return model("UNAVAILABLE", "Invitation is unavailable.");
    return {
        state: "ACCEPTED",
        returnTo: `/families/${encodeURIComponent(familyId)}/welcome`,
        message: "Welcome to your family workspace.",
    };
}
function model(state, message) {
    return { state, returnTo: "/inventory", message };
}
//# sourceMappingURL=family-journey.js.map