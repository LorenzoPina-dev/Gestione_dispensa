export type ShoppingAction = "ACCEPT" | "REJECT" | "SNOOZE" | "COMPLETE" | "EDIT";
export type ShoppingState = "IDLE" | "SUBMITTING" | "SUCCESS" | "CONFLICT" | "RETRYABLE_ERROR" | "OFFLINE";
export interface ShoppingJourneyModel {
    readonly state: ShoppingState;
    readonly action: ShoppingAction;
    readonly listVersion: number;
    readonly message: string;
}
export declare function beginShoppingAction(action: ShoppingAction, listVersion: number): ShoppingJourneyModel;
export declare function resolveShoppingResult(model: ShoppingJourneyModel, result: "SUCCESS" | "CONFLICT" | "RETRYABLE_ERROR" | "OFFLINE"): ShoppingJourneyModel;
