export type ProductInputSource = "MANUAL" | "BARCODE" | "PHOTO" | "IMPORT";
export type ProductInputState = "INPUT" | "SUBMITTING" | "REVIEW" | "MANUAL_REQUIRED" | "SUCCESS" | "OFFLINE" | "CONFLICT" | "RETRYABLE_ERROR";
export interface ProductInputModel {
    readonly source: ProductInputSource;
    readonly state: ProductInputState;
    readonly message: string;
    readonly retryable: boolean;
}
export type ExpiryState = "UNKNOWN" | "FRESH" | "EXPIRING" | "EXPIRED";
export declare function beginProductInput(source: ProductInputSource): ProductInputModel;
export declare function resolveProductInput(model: ProductInputModel, result: "CANDIDATE" | "MANUAL_REQUIRED" | "SUCCESS" | "OFFLINE" | "CONFLICT" | "RETRYABLE_ERROR"): ProductInputModel;
export declare function getExpiryState(expiresAt: string | undefined, now: string, expiringWithinDays?: number): ExpiryState;
