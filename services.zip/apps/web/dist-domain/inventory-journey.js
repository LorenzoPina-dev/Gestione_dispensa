export function beginInventoryAction(action, version) {
    if (!Number.isInteger(version) || version < 0) {
        return { state: "RETRYABLE_ERROR", action, message: "The stock version is invalid." };
    }
    return { state: "SUBMITTING", action, message: "Saving stock movement.", version };
}
export function resolveInventoryResult(model, result) {
    const messages = {
        SUCCESS: "Stock updated.",
        CONFLICT: "Stock changed elsewhere. Review before retrying.",
        RETRYABLE_ERROR: "The stock update can be retried.",
        OFFLINE: "You are offline. The update will retry when connected.",
    };
    return { ...model, state: result, message: messages[result] };
}
//# sourceMappingURL=inventory-journey.js.map