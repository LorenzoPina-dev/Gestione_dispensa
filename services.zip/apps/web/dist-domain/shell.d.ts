export type ViewState = "LOADING" | "READY" | "ERROR" | "OFFLINE" | "RETRYING";
export interface FamilyContext {
    readonly familyId: string;
    readonly displayName: string;
}
export interface Principal {
    readonly userId: string;
    readonly displayName: string;
}
export interface ShellModel {
    readonly principal: Principal | undefined;
    readonly family: FamilyContext | undefined;
    readonly state: ViewState;
    readonly errorMessage: string | undefined;
    readonly navigation: readonly NavigationItem[];
}
export interface NavigationItem {
    readonly href: string;
    readonly label: string;
    readonly current: boolean;
}
export declare function createShellModel(input: {
    readonly principal?: Principal;
    readonly family?: FamilyContext;
    readonly state?: ViewState;
    readonly errorMessage?: string;
    readonly currentPath?: string;
}): ShellModel;
export declare function resolveSafeRedirect(value: string | undefined, fallback?: string): string;
export declare function shellStatusMessage(model: ShellModel): string;
