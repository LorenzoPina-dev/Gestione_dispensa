export function beginShoppingAction(action, listVersion) {
    if (!Number.isInteger(listVersion) || listVersion < 0) {
        return {
            state: "RETRYABLE_ERROR",
            action,
            listVersion,
            message: "The shopping list version is invalid.",
        };
    }
    return { state: "SUBMITTING", action, listVersion, message: "Saving shopping list changes." };
}
export function resolveShoppingResult(model, result) {
    const messages = {
        SUCCESS: "Shopping list updated.",
        CONFLICT: "The list changed elsewhere. Review before retrying.",
        RETRYABLE_ERROR: "The list update can be retried.",
        OFFLINE: "You are offline. The update will retry when connected.",
    };
    return { ...model, state: result, message: messages[result] };
}
//# sourceMappingURL=shopping-journey.js.map